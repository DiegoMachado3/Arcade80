<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="cadastro_pontos.css">
    <title>Cadastro de pontos</title>
</head>
<body>

  <h1 class="titulo">CADASTRO DE PONTOS</h1>

  <div class="retangulo_img" ><img src="Rectangle 1.png"></div>
  <div class="retangulo_img2" ><img src="Rectangle 2.png"></div>
  <div class="retangulo_img3" ><img src="Rectangle 3.png"></div>
  <div class="retangulo_img4" ><img src="Rectangle 4.png"></div>
  <div class="retangulo_img5" ><img src="Rectangle 5.png"></div> 
  

  
  <h1 class="titulo1">Somente Pessoal Autorizado</h1>

  <div class="selectp">
        <label for="text"><b>SELECT</b></label><br>
  </div>

  <div class="selectpl">
        <label for="text"><b>PLAYER</b></label><br>
  </div>

  <div class="selectg">
        <label for="text"><b>SELECT</b></label><br>
  </div>

  <div class="selectga">
        <label for="text"><b>GAME</b></label><br>
  </div>

  <div class="cadastro_Score">
        <input type="number" name="cadastro_score" id="cadastro_score"><br>
  </div>

  <div class="selectsc">
        <label for="text"><b>SELECT SCORE</b></label><br>
  </div>

  <div class='botoes_login'>
        <input class='botao' type="submit" name="logar" value="Cadastrar"><br/>
</div>

</body>
</html>