<?php

include_once('connect.php');

$nome = '';
$email = '';
$senha = '';
$confirmsenha = '';
$gravar = '';

if(!empty($_POST['nome_cadastro'])){
    $nome = $_POST['nome_cadastro'];
    echo "$nome";
}

if(!empty($_POST['email_cadastro'])){
    $email = $_POST['email_cadastro'];
}

if(!empty($_POST['senha_cadastro'])){
    $senha = $_POST['senha_cadastro'];
}

if(!empty($_POST['Confirmsenha_cadastro'])){
    $confirmsenha = $_POST['Confirmsenha_cadastro'];
}

if(!empty($_POST['registrar'])){
    $gravar = $_POST['registrar'];
}

// if ($senha = $confirmsenha){
    if($gravar == 'Registrar'){
        $res_gravar = "INSERT INTO usuarios(nome_user,email_user,senha_user) VALUES ('$nome','$email','$senha')";
        $resposta_gravar = mysqli_query($conn,$res_gravar);
        echo "dados gravados";
    
    }
// }




?>