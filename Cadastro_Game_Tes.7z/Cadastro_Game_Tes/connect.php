<?php

$server = "127.0.0.1:3307"; 
$user = "root"; 
$password = ""; 
$db = "ds-one"; 

$conn = mysqli_connect($server, $user, $password, $db);

// echo "conexão ok";
?>