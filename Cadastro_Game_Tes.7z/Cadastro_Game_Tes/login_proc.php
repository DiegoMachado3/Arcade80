<?php
include_once('connect.php');

$email = $_POST['email_login'];
$senha = $_POST['senha_login'];
$logar = $_POST['logar'];

if (isset($logar)) {

    $res_logar = mysqli_query($conn,"SELECT * FROM usuarios WHERE email_user = '$email' and senha_user = '$senha'");

    $row = mysqli_num_rows($res_logar);
      if ($row > 0){
        header("Location:cadastro.php");
        die();
      }else {
        echo"<script language='javascript' type='text/javascript'>
        alert('Login e/ou senha incorretos');window.location
        .href='';</script>";
      }
  }
?>