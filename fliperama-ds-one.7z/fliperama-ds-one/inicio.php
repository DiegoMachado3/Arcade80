<head>
    <title>Inicio</title>
</head>
<?php
include_once('menu.php');
?>
<body id="game-bg" background="game-bg.png"></body>
    <div class="body">
        <img class="linha1" src="linha.png">
        <h1 class="arcade">ARCADE</h1>
        <div class="linha80">
            <img class="linha2" src="linha.png">
            <h1 class="l80">80</h1>
            <img class="linha2" src="linha.png">
        </div>
        <h1 class="start">Press Start</h1>
        <div class="creditos">
            <h4>© Corporation Senai Games 1989</h4>
            <h4>ALL RIGHTS RESERVED</h4>
        </div>
    </div>
</body>
</html>