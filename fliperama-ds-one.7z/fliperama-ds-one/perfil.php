<head>
    <title>Perfil</title>
</head>
<?php
include_once('menu.php');
?>
<body class="body_perfil" >

<h1 class="titulo">ACCOUNT ARCADE-80</h1>

<div class="text_rank">
    <label for="text"><b>RANK</b></label><br>
</div>

<h1 class="text_exit">EXIT</h1>

<h1 class="text_player">PLAYER</h1>
<h1 class="text_email">EMAIL</h1>
<h1 class="text_scores">HIGH SCORES</h1>
<h1 class="text_perfil">PERFIL</h1>
    
</body>
</html>