<head>
    <title>Jogos</title>
</head>
<?php
include_once('menu.php');
?>
<body id="jogosbg" background="jogosbg.png"></body>
    <div class="gamespg">
        <div class="gamestop">
            <img class="linha3" src="linha.png">
            <h1 class="gamestt">GAMES</h1>
            <img class="linha3" src="linha.png">
        </div>

        <div class="gameslist">
            
        </div>
    </div>
</body>
</html>