<head>
    <title>Rank</title>
</head>
<?php
include_once('menu.php');
?>
<body id="jogosbg"></body>
    <div class="gamespg">
        <div class="gamestop">
            <img class="linha4" src="linha.png">
            <h1 class="gamestt">RANK</h1>
            <img class="linha4" src="linha.png">
        </div>
        <div class="ranklist">

        </div>
        <div class="pacman">
            <img src="pacman.png">
        </div>
    </div>
</body>
</html>